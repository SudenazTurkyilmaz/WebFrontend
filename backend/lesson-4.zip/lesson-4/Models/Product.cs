using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lesson_1.Models
{
    public class Product
    {
        public int Id { get; set; }

        public required string Name { get; set; }

        public int Count { get; set; } = 0;

        public int CategoryId { get; set; }

        public required virtual Category Category { get; set; }

        public virtual List<Tag> Tags { get; set; } = [];

    }
}