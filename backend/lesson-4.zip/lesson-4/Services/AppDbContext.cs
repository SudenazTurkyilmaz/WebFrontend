using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lesson_1.Models;
using Microsoft.EntityFrameworkCore;

namespace lesson_1.Services
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {

        }

        public required DbSet<Product> Products { get; set; }
        public required DbSet<Category> Categories { get; set; }
        public required DbSet<Tag> Tags { get; set; }
        public required DbSet<User> Users { get; set; }

    }
}