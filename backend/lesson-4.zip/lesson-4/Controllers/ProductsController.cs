using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using lesson_1.Dtos;
using lesson_1.Models;
using lesson_1.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace lesson_1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProductsController : ControllerBase
    {
        private AppDbContext dbContext;
        public ProductsController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult getAllProducts()
        {
            // var claims = HttpContext.User.Identity as ClaimsIdentity;
            // if (claims != null)
            // {
            //     return Ok(claims.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            // }
            var products = dbContext.Products.Include(p => p.Category).Include(p => p.Tags).ToList();
            return Ok(products);
        }


        [HttpGet]
        [Route("{productId:int}")]
        public IActionResult getProductById(int productId)
        {
            // var productObj = dbContext.Products.Find(productId);
            var productObj = dbContext.Products.Include(p => p.Category).FirstOrDefault(p => p.Id == productId);
            if (productObj is null)
                return NotFound();
            return Ok(productObj);
        }


        [HttpPost]
        public IActionResult createProduct(ProductDto dto)
        {
            var categoryObj = dbContext.Categories.Find(dto.CategoryId);
            if (categoryObj is null)
                return NotFound();
            var productObj = new Product()
            {
                Name = dto.Name,
                Count = dto.Count,
                Category = categoryObj,
            };

            dbContext.Products.Add(productObj);

            dbContext.SaveChanges();

            return Ok(productObj);
        }


        [HttpPut]
        [Route("{productId:int}")]
        public IActionResult updateProduct(int productId, ProductDto dto)
        {
            var categoryObj = dbContext.Categories.Find(dto.CategoryId);
            if (categoryObj is null)
                return NotFound();

            var productObj = dbContext.Products.Find(productId);
            if (productObj is null)
                return NotFound();

            productObj.Name = dto.Name;
            productObj.Count = dto.Count;
            productObj.Category = categoryObj;

            dbContext.SaveChanges();

            return Ok(productObj);
        }


        [HttpDelete]
        [Route("{productId:int}")]
        public IActionResult updateProduct(int productId)
        {
            var productObj = dbContext.Products.Find(productId);
            if (productObj is null)
                return NotFound();

            dbContext.Products.Remove(productObj);

            dbContext.SaveChanges();

            return Ok(productObj);
        }

        [HttpPost]
        [Route("{productId:int}/Tags")]
        public IActionResult AddTag(int productId, ProductTagDto dto)
        {
            var productObj = dbContext.Products.Include(p => p.Tags).FirstOrDefault(p => p.Id == productId);
            var tagObj = dbContext.Tags.Find(dto.TagId);
            if (productObj is null || tagObj is null)
                return NotFound();

            productObj.Tags.Add(tagObj);

            dbContext.SaveChanges();
            return Ok(productObj);
        }

        [HttpDelete]
        [Route("{productId:int}/Tags")]
        public IActionResult RemoveTag(int productId, ProductTagDto dto)
        {
            var productObj = dbContext.Products.Include(p => p.Tags).FirstOrDefault(p => p.Id == productId);
            var tagObj = dbContext.Tags.Find(dto.TagId);
            if (productObj is null || tagObj is null)
                return NotFound();

            productObj.Tags.Remove(tagObj);

            dbContext.SaveChanges();
            return Ok(productObj);
        }

    }
}