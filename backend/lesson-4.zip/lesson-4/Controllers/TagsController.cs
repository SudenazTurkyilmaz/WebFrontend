using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lesson_1.Dtos;
using lesson_1.Models;
using lesson_1.Services;
using Microsoft.AspNetCore.Mvc;

namespace lesson_1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TagsController : ControllerBase
    {
        private AppDbContext dbContext;
        public TagsController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult getAllTags()
        {
            var Tags = dbContext.Tags.ToList();
            return Ok(Tags);
        }


        [HttpGet]
        [Route("{TagId:int}")]
        public IActionResult getTagById(int TagId)
        {
            var TagObj = dbContext.Tags.Find(TagId);
            // var TagObj = dbContext.Tags.FirstOrDefault(p => p.Id == TagId);
            if (TagObj is null)
                return NotFound();
            return Ok(TagObj);
        }


        [HttpPost]
        public IActionResult createTag(TagDto dto)
        {
            var TagObj = new Tag()
            {
                Name = dto.Name,
            };

            dbContext.Tags.Add(TagObj);

            dbContext.SaveChanges();

            return Ok(TagObj);
        }


        [HttpPut]
        [Route("{TagId:int}")]
        public IActionResult updateTag(int TagId, TagDto dto)
        {
            var TagObj = dbContext.Tags.Find(TagId);
            if (TagObj is null)
                return NotFound();

            TagObj.Name = dto.Name;

            dbContext.SaveChanges();

            return Ok(TagObj);
        }


        [HttpDelete]
        [Route("{TagId:int}")]
        public IActionResult updateTag(int TagId)
        {
            var TagObj = dbContext.Tags.Find(TagId);
            if (TagObj is null)
                return NotFound();

            dbContext.Tags.Remove(TagObj);

            dbContext.SaveChanges();

            return Ok(TagObj);
        }

    }
}